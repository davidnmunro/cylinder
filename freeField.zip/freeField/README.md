# Free field tutorial

## Notes
This is a quarter symmetry case of a square charge with multiple detonation points in an open field. The charge is a 50 kg box of c-4.

The case uses adaptive mesh refinement, and took approximately 10 min to complete on a four core desktop.


